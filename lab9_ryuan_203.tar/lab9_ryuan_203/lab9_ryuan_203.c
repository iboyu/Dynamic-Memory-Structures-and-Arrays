#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#define size 50




 int N = 5;
 int order = 0;

typedef struct
{
    int itemId;
    char itemName[size];
    int quantity;
    double pricePerItem;
} Item;

void displayMenu()
{
    printf("*************************\n");
    printf("Enter your Choice:\n");
    printf("'i' - insert an item\n");
    printf("'u' - update the database\n");
    printf("'s' - search the database\n");
    printf("'d' - display the database\n");
    printf("'q' - quit the program\n");
    printf("*************************\n");
}
Item getItem()
{
    char inBuff[size];
    Item myItem;
    printf("What is the item ID: \n");
    fgets(inBuff, size, stdin);
    sscanf(inBuff, "%i", &myItem.itemId);
    printf("What is the item name: \n");
    fgets(inBuff, size, stdin);
    sscanf(inBuff, "%[^\n]", myItem.itemName);
    printf("What is the item quantity: \n");
    fgets(inBuff, size, stdin);
    sscanf(inBuff, "%i", &myItem.quantity);
    printf("What is the item per price: \n");
    fgets(inBuff, size, stdin);
    sscanf(inBuff, "%lf", &myItem.pricePerItem);

    return myItem;
}
void insertItem(Item *itemInventory, Item item)
{
    int i, j = 1;
    for(i = 0; i < order; i++){
        if(itemInventory[i].itemId == item.itemId){
            printf("Error Inserting an Item.\n");
            j = 0;
        }
    }
        if(j == 1){
            if(order < (N-1)){
                itemInventory[order] = item;
                order++;
            }else{
                N = N * 2;
                itemInventory = (Item *)realloc(itemInventory, N);
                if(itemInventory == NULL){
                    printf("Realloc failed.Exit.\n");
                    exit(-1);
                }
                itemInventory[order] = item;
                order++;
            }
        }

}

void updateItem(Item *itemInventory, int tempID, int tempQuantity){
    int i, j = 0;   
    for(i = 0; i < order; i++){
        if(itemInventory[i].itemId != tempID){
            j++;
        }
        else if(itemInventory[i].itemId == tempID){
            itemInventory[i].quantity = tempQuantity;
        }
    }
    if(j == order){
        printf("Item Not Found.\n");
    }
}

void searchItem(Item *itemInventory, int itemID){
    int i, j = 0;
    for(i = 0; i < order; i++){
        if(itemInventory[i].itemId != itemID){
            j++;
        }
        else if(itemInventory[i].itemId == itemID){
            printf("******************************\n");
            printf("Item ID: %i\n", itemInventory[i].itemId);
            printf("Item Name: %s\n", itemInventory[i].itemName);
            printf("Item Quantity: %i\n", itemInventory[i].quantity);
            printf("Price per Item: %.2f\n", itemInventory[i].pricePerItem);
            printf("******************************\n");
        }
    }
    if(j == order){
        printf("Item Not Found.\n");
    }
}

void printData(Item *itemInventory){
    int i;
    printf("************************************************************\n");
    printf(" Item ID\tItem Name\tItem Quantity\tItem Price  \n");
    printf("************************************************************\n");
        for(i = 0; i < order; i++){           
                printf(" %-15d %-15s %-15i %-10.2f\n",itemInventory[i].itemId, itemInventory[i].itemName, itemInventory[i].quantity, itemInventory[i].pricePerItem);                     
        }
    
}

int main()
{

    char inbuf[size], choice;
    int tempID, tempQuantity;

    Item *itemInventory;
    itemInventory = (Item *)malloc(sizeof(Item) * N);
    if(itemInventory == NULL){
        printf("Malloc failed. Exit\n");
        exit(-1);
    }

    printf("This program is used to develop a simple database of information about items.\n");
    do
    {
        displayMenu();
        fgets(inbuf, size, stdin);
        sscanf(inbuf, "%c", &choice);
        choice = toupper(choice);

        switch (choice)
        {
            case 'I':
            {   
                Item item;
                printf("This option is to insert the item.\n");                
                item = getItem();
                insertItem(itemInventory, item);
                printf("The current length is: %i\n",N);
                break;
            }

            case 'U':
            {   
                printf("This option is to update the quantity with the exiting ID.\n");
                printf("Please enter the item ID that you want to update:\n");
                fgets(inbuf, size, stdin);
                sscanf(inbuf, "%i", &tempID);
                printf("Please enter the new quantity that you want to update:\n");
                fgets(inbuf, size, stdin);
                sscanf(inbuf, "%i", &tempQuantity);
                updateItem(itemInventory, tempID, tempQuantity);
                break;
            }

            case 'S':
            {   
                printf("This option is to search the item you want.\n");
                printf("Please enter the item ID that you want to find:\n");
                fgets(inbuf, size, stdin);
                sscanf(inbuf, "%i", &tempID);
                searchItem(itemInventory, tempID);
                break;
            }

            case 'D':
            {
                printData(itemInventory);
                break;
            }

            default:
            {
                if (choice != 'Q')
                {
                    printf("'%c' is not a valid choice. Please input again!\n", choice);
                }
                else
                {
                    printf("Thank you for using. Goodbye!\n");
                }
            }
        }
    }while (choice != 'Q');
                              
    free(itemInventory);
    return 0;
}